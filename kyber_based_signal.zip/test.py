from ccakem import *

priv, pub = kem_keygen1024()
print(len(priv))
print(len(pub))

